import streamlit as st
import requests
import json
from pathlib import Path
import time
import logging
from datetime import datetime
from history_view import load_history_view as show_history

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler("streamlit_app.log"), logging.StreamHandler()],
)
logger = logging.getLogger(__name__)

# 페이지 기본 설정
st.set_page_config(page_title="계약서 분석기", page_icon="📋", layout="wide")

# CSS 스타일 적용
st.markdown(
    """
<style>
    .main {
        padding: 2rem;
    }
    .stProgress > div > div > div > div {
        background-color: #1E88E5;
    }
    .upload-box {
        border: 2px dashed #cccccc;
        border-radius: 5px;
        padding: 2rem;
        text-align: center;
    }
    .result-box {
        background-color: #f8f9fa;
        border-radius: 5px;
        padding: 1.5rem;
        margin: 1rem 0;
    }
    .violation-item {
        border-left: 3px solid #ff4b4b;
        padding-left: 1rem;
        margin: 1rem 0;
    }
</style>
""",
    unsafe_allow_html=True,
)


def analyze_contract(file):
    """계약서 분석 API 호출"""
    API_URL = "http://localhost:5003/analyze_contract"

    try:
        logger.info("=" * 50)
        logger.info(f"계약서 분석 요청 시작: {file.name}")
        logger.info(f"파일 크기: {file.size / 1024:.2f}KB")
        logger.info(f"API 엔드포인트: {API_URL}")

        files = {"file": file}

        logger.info("API 요청 시작")
        start_time = time.time()
        response = requests.post(API_URL, files=files)
        end_time = time.time()

        logger.info(f"API 응답 시간: {end_time - start_time:.2f}초")
        logger.info(f"응답 상태 코드: {response.status_code}")

        response.raise_for_status()
        result = response.json()
        logger.info(f"result {result}")
        # logger.info(f"result.get('results') {result.get('results')}")
        logger.info(f"result.get('metadata') {result.get('metadata'),{}}")
        metadata = result.get("metadata", {})

        logger.info("API 응답 결과:")
        logger.info(f"- 총 섹션 수: {metadata.get('total_sections', 0)}")
        logger.info(f"- 위반 건수: {metadata.get('violation_count', 0)}")
        logger.info("=" * 50)

        if result:
            # 분석 결과 저장
            try:
                with open("analysis_history.json", "r", encoding="utf-8") as f:
                    history = json.load(f)
            except FileNotFoundError:
                history = {}

            # 현재 분석 결과 저장
            history[file.name] = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                **result,
            }

            # 파일에 저장
            with open("analysis_history.json", "w", encoding="utf-8") as f:
                json.dump(history, f, ensure_ascii=False, indent=2)

        return result
    except requests.exceptions.RequestException as e:
        logger.error(f"API 호출 중 오류 발생: {str(e)}")
        st.error(f"API 호출 중 오류 발생: {str(e)}")
        return None


def main():
    # 사이드바
    with st.sidebar:
        st.title("📋 계약서 분석기")

        # 네비게이션 버튼들
        if "page" not in st.session_state:
            st.session_state.page = "main"

        if st.session_state.page == "main":
            # 메인 화면일 때는 이전 결과 조회 버튼만 표시
            if st.button("📋 이전 결과 조회", key="to_history"):
                st.session_state.page = "history"
                st.rerun()

            # 구분선 추가
            st.divider()

            # 파일 업로드
            uploaded_file = st.file_uploader(
                "PDF 파일을 업로드하세요",
                type=["pdf"],
                help="계약서 또는 사양서 PDF 파일을 선택하세요.",
            )

            # 구분선 추가
            st.divider()

            # 작성 방법 안내
            st.markdown("### ✍️ 작성 방법")
            st.markdown(
                """
            #### 계약서 분석 방법
            1. PDF 파일을 업로드합니다.
            2. '분석 시작' 버튼을 클릭합니다.
            3. 분석 결과를 확인합니다.
            
            #### 지원하는 파일 형식
            - PDF 파일 (.pdf)
            
            #### 주의사항
            - 파일 크기는 최대 10MB까지 지원됩니다.
            - 텍스트가 포함된 PDF 파일만 분석 가능합니다.
            - 스캔된 이미지 PDF의 경우 분석이 제한될 수 있습니다.
            """
            )

        else:  # history 페이지일 때
            # 메인으로 돌아가기 버튼만 표시
            if st.button("← 메인으로 돌아가기", key="to_main"):
                st.session_state.page = "main"
                st.rerun()

    # 메인 컨텐츠
    if st.session_state.page == "history":
        # 이전 결과 조회 화면 로드
        show_history()
    else:
        # 파일첨부 화면을 기본으로 표시
        st.header("📄 계약서 분석")

        if not uploaded_file:
            st.info("👈 사이드바에서 PDF 파일을 업로드해주세요.")
            return

        # 분석 시작
        if st.button("분석 시작", type="primary"):
            logger.info(f"분석 시작 버튼 클릭: {uploaded_file.name}")

            with st.spinner("계약서를 분석중입니다..."):
                # 진행바 표시
                progress_bar = st.progress(0)
                for i in range(100):
                    time.sleep(0.01)
                    progress_bar.progress(i + 1)

                # API 호출 및 결과 분석
                logger.info("계약서 분석 API 호출")
                response = analyze_contract(uploaded_file)

                if response and "metadata" in response:
                    logger.info("분석 완료")
                    metadata = response["metadata"]
                    results = response.get("results", {})

                    st.success("분석이 완료되었습니다!")

                    # 결과 표시
                    col1, col2 = st.columns([2, 1])

                    with col1:
                        st.subheader("📊 분석 결과")
                        violation_count = metadata.get("violation_count", 0)
                        total_sections = metadata.get("total_sections", 0)

                        # 위반 사항 요약
                        st.metric(
                            "위반 조항 수",
                            f"{violation_count}건 / 전체 {total_sections}건",
                            delta=(
                                f"{(violation_count/total_sections*100):.1f}%"
                                if total_sections > 0
                                else "0%"
                            ),
                            delta_color="inverse",
                        )

                        # 위반 사항 상세 목록
                        if results:
                            for key, violation in results.items():
                                if "analysis" in violation:
                                    with st.expander(
                                        f"위반사항 - 페이지 {violation.get('page_number', 'N/A')}"
                                    ):
                                        analysis = violation["analysis"]
                                        st.markdown(
                                            f"""
                                            **📍 검출 위치:** {violation.get('identifier', 'N/A')}
                                            
                                            **📄 원문:**
                                            > {analysis.get('asis_sentence', '정보 없음')}
                                            
                                            **⚠️ 검토의견:**
                                            {analysis.get('comments', '의견 없음')}
                                            
                                            **💡 개선안:**
                                            {analysis.get('tobe_sentence', '제안 없음')}
                                        """
                                        )

                    with col2:
                        st.subheader("📈 통계")
                        # 메타데이터 표시
                        violation_ratio = (
                            (violation_count / total_sections * 100)
                            if total_sections > 0
                            else 0
                        )
                        st.metric("검토 항목 수", total_sections)

                        st.metric("위반 비율", f"{violation_ratio:.1f}%")

                        # 파일 정보
                        st.markdown("### 📑 파일 정보")
                        st.markdown(
                            f"""
                            - **파일명:** {metadata.get('file_name', 'N/A')}
                            - **처리시간:** {metadata.get('processed_at', 'N/A').split('T')[0]}
                        """
                        )

                        # 분석 모델 정보
                        if "vector_store" in metadata:
                            vector_store = metadata["vector_store"]
                            st.markdown("### 🤖 모델 정보")
                            st.markdown(
                                f"""
                                - **임베딩 모델:** {vector_store.get('embedding_model', 'N/A')}
                                - **모델 타입:** {vector_store.get('model_type', 'N/A')}
                            """
                            )


if __name__ == "__main__":
    logger.info("애플리케이션 시작")
    main()
