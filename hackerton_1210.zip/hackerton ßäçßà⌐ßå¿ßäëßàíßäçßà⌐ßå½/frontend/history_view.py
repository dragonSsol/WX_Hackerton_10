import os
import streamlit as st
from datetime import datetime, timedelta
import pandas as pd
from pathlib import Path
import io
import json
import sys
import requests
import logging
import io

# 프로젝트 루트 경로를 Python 경로에 추가
project_root = str(Path(__file__).parents[1])
sys.path.append(project_root)
from config import API_CONFIG

# CacheManager import
from src.cache_manager import CacheManager

# 로깅 설정
logger = logging.getLogger(__name__)


def fetch_all_analysis_keys():
    """모든 분석 결과의 키 목록 조회"""
    try:
        response = requests.get("http://localhost:5003/cache/info")
        response.raise_for_status()
        data = response.json()
        logger.info(f"캐시정보 결과 {data}")

        # API 응답 구조 검증
        if not isinstance(data, dict):
            logger.error("API 응답이 올바른 형식이 아님")
            st.error("API 응답 형식이 올바르지 않습니다")
            return []

        # status와 cache_info가 없는 경우에도 처리
        cache_info = data.get("cache_info", [])
        if not cache_info:
            logger.info("저장된 분석 결과가 없음")
            return []

        # 선택박스용 튜플 리스트 생성 (키, 표시텍스트)
        key_pairs = []
        for info in cache_info:
            try:
                # 필수 필드 확인
                cache_key = info.get("cache_key", "unknown")
                file_name = info.get("file_name", "N/A")
                analysis_type = info.get("analysis_type", "알 수 없음")
                violation_count = info.get("violation_count", 0)

                # created_at 처리
                created_at = info.get("created_at", "")
                if not created_at:
                    created_at = "날짜 없음"
                else:
                    try:
                        created_at = datetime.fromisoformat(created_at).strftime(
                            "%Y-%m-%d %H:%M:%S"
                        )
                    except ValueError:
                        created_at = "날짜 형식 오류"

                display_text = f"[{created_at}] {file_name} ({analysis_type}, 위반: {violation_count}건)"
                key_pairs.append((cache_key, display_text, info))

            except Exception as e:
                logger.warning(f"캐시 정보 처리 중 오류 발생: {str(e)}")
                continue

        return sorted(key_pairs, key=lambda x: x[1], reverse=True)

    except requests.exceptions.RequestException as e:
        logger.error(f"API 요청 중 오류 발생: {str(e)}")
        st.error("서버 연결에 실패했습니다")
        return []
    except Exception as e:
        logger.error(f"분석 키 목록 조회 중 오류: {str(e)}")
        st.error("분석 이력 조회 중 오류가 발생했습니다")
        return []


def fetch_analysis_result(key: str):
    """특정 키의 분석 결과 조회"""
    try:
        response = requests.get(f"http://localhost:5003/get_analysis_result/{key}")
        response.raise_for_status()
        return response.json()
    except Exception as e:
        st.error(f"분석 결과 조회 중 오류 발생: {str(e)}")
        return None


def load_history_view():
    st.title("계약서 분석 이력 조회")

    # 분석 결과 키 목록 조회
    analysis_keys = fetch_all_analysis_keys()

    if not analysis_keys:
        st.info("저장된 분석 이력이 없습니다.")
        return

    # 분석 결과 선택
    selected_item = st.selectbox(
        "조회할 분석 결과 선택", options=analysis_keys, format_func=lambda x: x[1]
    )

    if selected_item:
        selected_key = selected_item[0]
        cache_info = selected_item[2]
        response = fetch_analysis_result(selected_key)
        logger.info(f"API 응답: {response}")

        if response and "result" in response:
            # response의 'result' 키에서 실제 데이터 가져오기
            result_data = response["result"]
            logger.info(f"Result data: {result_data}")

            # metadata 추출
            metadata = result_data.get("metadata", {})
            logger.info(f"Metadata: {metadata}")

            if metadata:
                # vector_store 정보 추출
                vector_store = metadata.get("vector_store", {})
                logger.info(f"Vector store: {vector_store}")

                # 메타데이터 표시
                st.subheader("📊 분석 개요")
                # 메트릭 표시를 위한 컬럼 생성
                col1, col2, col3, col4 = st.columns(4)

                with col1:
                    st.metric(
                        "분석 유형", cache_info.get("analysis_type", "알 수 없음")
                    )
                with col2:
                    st.metric("전체 페이지", cache_info.get("total_pages", 0))
                with col3:
                    st.metric("전체 문장", cache_info.get("total_sentences", 0))
                with col4:
                    st.metric(
                        "위반 건수",
                        cache_info.get("violation_count", 0),
                        delta=None,
                        delta_color="inverse",  # 위반 건수는 낮을수록 좋으므로
                    )

                # Embedding 모델 정보 표시
                st.subheader("🤖 분석 모델 정보")

                if vector_store:
                    st.metric(
                        "Embedding 모델", vector_store.get("embedding_model", "N/A")
                    )

            # 위반 사항 목록
            st.subheader("📝 위반 사항 목록")
            violations = result_data.get("violations", {})
            logger.info(f"@@@@@@@@@@violations {violations}")

            if violations:
                # 데이터프레임으로 변환하기 위한 리스트
                violation_records = []
                for section_id, violation in violations.items():
                    try:
                        analysis = violation.get("analysis", {})
                        record = {
                            "검출ID": violation.get("identifier", "N/A"),
                            "페이지": violation.get("page_number", "N/A"),
                            "검출 문장": analysis.get(
                                "asis_sentence", violation.get("content", "N/A")
                            ),
                            "검토의견": analysis.get("comments", "N/A"),
                            "추천 문장": analysis.get("tobe_sentence", "N/A"),
                        }
                        violation_records.append(record)
                    except Exception as e:
                        logger.error(f"위반 사항 처리 중 오류: {str(e)}")
                        continue

                if violation_records:
                    df = pd.DataFrame(violation_records)
                    st.dataframe(
                        df,
                        use_container_width=True,
                        column_config={
                            "검출ID": st.column_config.TextColumn(
                                "검출ID", width="medium", help="위반 사항 고유 식별자"
                            ),
                            "페이지": st.column_config.NumberColumn(
                                "페이지", width="small", help="문서 내 페이지 번호"
                            ),
                            "검출 문장": st.column_config.TextColumn(
                                "검출 문장",
                                width="large",
                                help="위반 사항이 발견된 원문",
                            ),
                            "검토의견": st.column_config.TextColumn(
                                "검토의견",
                                width="large",
                                help="위반 사항에 대한 검토 의견",
                            ),
                            "추천 문장": st.column_config.TextColumn(
                                "추천 문장", width="large", help="개선을 위한 추천 문장"
                            ),
                        },
                    )

                    # 내보내기 옵션
                    st.divider()
                    st.subheader("💾 결과 내보내기")

                    """
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        # JSON 다운로드
                        json_str = json.dumps(response, ensure_ascii=False, indent=2)
                        st.download_button(
                            label="JSON 파일 다운로드",
                            data=json_str,
                            file_name=f"analysis_result_{selected_key}.json",
                            mime="application/json",
                            help="분석 결과를 JSON 형식으로 다운로드합니다.",
                        )
                    

                    with col1:
                    """
                    # Excel 다운로드
                    excel_buffer = io.BytesIO()
                    df.to_excel(excel_buffer, index=False)

                    st.download_button(
                        label="Excel 파일 다운로드",
                        data=excel_buffer.getvalue(),
                        file_name=f"analysis_result_{selected_key}.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        help="위반 사항 목록을 Excel 형식으로 다운로드합니다.",
                    )
            else:
                st.info("위반 사항이 없습니다.")


if __name__ == "__main__":
    load_history_view()
