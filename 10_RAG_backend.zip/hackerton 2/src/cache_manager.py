import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional, Any
import threading
import os

logger = logging.getLogger(__name__)


class CacheManager:
    def __init__(self, cache_dir: str = "cache"):
        """
        캐시 매니저 초기화
        Args:
            cache_dir: 캐시 파일을 저장할 디렉토리 경로
        """
        self.cache_dir = Path(cache_dir)
        self.cache_file = self.cache_dir / "analysis_cache.json"
        self.lock = threading.Lock()
        self._initialize_cache()

        logger.info(f"캐시 매니저 초기화 완료 (캐시 디렉토리: {self.cache_dir})")

    def _initialize_cache(self):
        """캐시 디렉토리와 파일 초기화"""
        try:
            # 캐시 디렉토리 생성
            self.cache_dir.mkdir(parents=True, exist_ok=True)

            # 캐시 파일이 없으면 빈 캐시로 초기화
            if not self.cache_file.exists():
                self._save_cache({})
                logger.info("새로운 캐시 파일 생성")
            else:
                logger.info("기존 캐시 파일 로드")

        except Exception as e:
            logger.error(f"캐시 초기화 중 오류 발생: {str(e)}")
            raise

    def _load_cache(self) -> Dict:
        """캐시 파일 로드"""
        try:
            with self.cache_file.open("r", encoding="utf-8") as f:
                return json.load(f)
        except FileNotFoundError:
            logger.warning("캐시 파일이 없어 빈 캐시 반환")
            return {}
        except json.JSONDecodeError:
            logger.error("손상된 캐시 파일 감지, 새로운 캐시로 초기화")
            return {}
        except Exception as e:
            logger.error(f"캐시 로드 중 오류 발생: {str(e)}")
            return {}

    def _save_cache(self, cache_data: Dict):
        """캐시 파일 저장"""
        try:
            with self.cache_file.open("w", encoding="utf-8") as f:
                json.dump(cache_data, f, ensure_ascii=False, indent=2)
            logger.debug("캐시 파일 저장 완료")
        except Exception as e:
            logger.error(f"캐시 저장 중 오류 발생: {str(e)}")
            raise

    def save_result(self, section_number: int, result: Dict[str, Any]):
        """
        분석 결과를 캐시에 저장
        Args:
            section_number: 섹션 번호
            result: 저장할 분석 결과
        """
        try:
            with self.lock:
                logger.info(f"섹션 {section_number} 결과 캐시 저장 시작")

                # 현재 시간 추가
                result["timestamp"] = datetime.now().isoformat()

                # 캐시 로드
                cache_data = self._load_cache()

                # 결과 저장
                cache_data[str(section_number)] = result

                # 캐시 파일 저장
                self._save_cache(cache_data)

                logger.info(f"섹션 {section_number} 결과 캐시 저장 완료")

        except Exception as e:
            logger.error(f"결과 저장 중 오류 발생: {str(e)}")
            raise

    def get_result(self, section_number: int) -> Optional[Dict]:
        """
        특정 섹션의 캐시된 결과 조회
        Args:
            section_number: 조회할 섹션 번호
        Returns:
            캐시된 결과 또는 None
        """
        try:
            with self.lock:
                logger.info(f"섹션 {section_number} 결과 조회")
                cache_data = self._load_cache()
                result = cache_data.get(str(section_number))

                if result:
                    logger.info(f"섹션 {section_number} 캐시 결과 찾음")
                else:
                    logger.info(f"섹션 {section_number} 캐시 결과 없음")

                return result

        except Exception as e:
            logger.error(f"결과 조회 중 오류 발생: {str(e)}")
            return None

    def get_all_results(self) -> Dict:
        """
        모든 캐시된 결과 조회
        Returns:
            모든 캐시된 결과를 담은 딕셔너리
        """
        try:
            with self.lock:
                logger.info("전체 캐시 결과 조회")
                cache_data = self._load_cache()

                logger.info(f"총 {len(cache_data)} 개의 캐시된 결과 조회됨")
                return cache_data

        except Exception as e:
            logger.error(f"전체 결과 조회 중 오류 발생: {str(e)}")
            return {}

    def clear_cache(self):
        """캐시 초기화"""
        try:
            with self.lock:
                logger.info("캐시 초기화 시작")
                self._save_cache({})
                logger.info("캐시 초기화 완료")

        except Exception as e:
            logger.error(f"캐시 초기화 중 오류 발생: {str(e)}")
            raise

    def get_cache_info(self) -> Dict:
        """
        캐시 정보 조회
        Returns:
            캐시 정보를 담은 딕셔너리
        """
        try:
            with self.lock:
                cache_data = self._load_cache()
                cache_size = (
                    os.path.getsize(self.cache_file) if self.cache_file.exists() else 0
                )

                return {
                    "total_entries": len(cache_data),
                    "cache_file_size": cache_size,
                    "last_modified": (
                        datetime.fromtimestamp(
                            self.cache_file.stat().st_mtime
                        ).isoformat()
                        if self.cache_file.exists()
                        else None
                    ),
                    "cache_directory": str(self.cache_dir),
                }

        except Exception as e:
            logger.error(f"캐시 정보 조회 중 오류 발생: {str(e)}")
            return {}

    def save_analysis_result(self, key: str, result: Dict[str, Any]):
        """
        전체 분석 결과를 캐시에 저장
        Args:
            key: 분석 결과의 유일한 키 (예: 타임스탬프)
            result: 저장할 전체 분석 결과
        """
        try:
            with self.lock:
                logger.info(f"분석 결과 캐시 저장 시작 (키: {key})")

                # 캐시 로드
                cache_data = self._load_cache()

                # 결과 저장
                cache_data[key] = result

                # 캐시 파일 저장
                self._save_cache(cache_data)

                logger.info(f"분석 결과 캐시 저장 완료 (키: {key})")

        except Exception as e:
            logger.error(f"결과 저장 중 오류 발생: {str(e)}")
            raise

    def get_analysis_result(self, key: str) -> Optional[Dict]:
        """
        특정 키의 분석 결과 조회
        Args:
            key: 조회할 분석 결과의 키
        Returns:
            캐시된 분석 결과 또는 None
        """
        try:
            with self.lock:
                logger.info(f"분석 결과 캐시 조회 (키: {key})")
                cache_data = self._load_cache()
                result = cache_data.get(key)

                if result:
                    logger.info(f"분석 결과 캐시 찾음 (키: {key})")
                else:
                    logger.info(f"분석 결과 캐시 없음 (키: {key})")

                return result

        except Exception as e:
            logger.error(f"결과 조회 중 오류 발생: {str(e)}")
            return None
