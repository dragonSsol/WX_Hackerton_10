import streamlit as st
import requests
import json
from pathlib import Path
import time
import logging
from datetime import datetime
from history_view import load_history_view as show_history

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler("streamlit_app.log"), logging.StreamHandler()],
)
logger = logging.getLogger(__name__)

# 페이지 기본 설정
st.set_page_config(page_title="계약서 분석기", page_icon="📋", layout="wide")

# CSS 스타일 적용
st.markdown(
    """
<style>
    .main {
        padding: 2rem;
    }
    .stProgress > div > div > div > div {
        background-color: #1E88E5;
    }
    .upload-box {
        border: 2px dashed #cccccc;
        border-radius: 5px;
        padding: 2rem;
        text-align: center;
    }
    .result-box {
        background-color: #f8f9fa;
        border-radius: 5px;
        padding: 1.5rem;
        margin: 1rem 0;
    }
    .violation-item {
        border-left: 3px solid #ff4b4b;
        padding-left: 1rem;
        margin: 1rem 0;
    }
</style>
""",
    unsafe_allow_html=True,
)


def analyze_contract(file):
    """계약서 분석 API 호출"""
    API_URL = "http://localhost:5003/analyze_contract"

    try:
        logger.info("=" * 50)
        logger.info(f"계약서 분석 요청 시작: {file.name}")
        logger.info(f"파일 크기: {file.size / 1024:.2f}KB")
        logger.info(f"API 엔드포인트: {API_URL}")

        files = {"file": file}

        logger.info("API 요청 시작")
        start_time = time.time()
        response = requests.post(API_URL, files=files)
        end_time = time.time()

        logger.info(f"API 응답 시간: {end_time - start_time:.2f}초")
        logger.info(f"응답 상태 코드: {response.status_code}")

        response.raise_for_status()
        result = response.json()

        logger.info("API 응답 결과:")
        logger.info(f"- 총 섹션 수: {result.get('total_sections', 0)}")
        logger.info(f"- 위반 건수: {result.get('violation_count', 0)}")
        logger.info("=" * 50)

        if result:
            # 분석 결과 저장
            try:
                with open("analysis_history.json", "r", encoding="utf-8") as f:
                    history = json.load(f)
            except FileNotFoundError:
                history = {}

            # 현재 분석 결과 저장
            history[file.name] = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                **result,
            }

            # 파일에 저장
            with open("analysis_history.json", "w", encoding="utf-8") as f:
                json.dump(history, f, ensure_ascii=False, indent=2)

        return result
    except requests.exceptions.RequestException as e:
        logger.error(f"API 호출 중 오류 발생: {str(e)}")
        st.error(f"API 호출 중 오류 발생: {str(e)}")
        return None


def main():
    # 사이드바
    with st.sidebar:
        # st.image("logo.png", width=150)  # 로고 이미지 라인 주석 처리
        st.title("📋 계약서 분석기")

        # 카테고리 선택
        category = st.selectbox("분석 카테고리", ["작성방법", "파일첨부"])
        logger.info(f"선택된 카테고리: {category}")

        # 파일 업로드
        uploaded_file = st.file_uploader(
            "PDF 파일을 업로드하세요",
            type=["pdf"],
            help="계약서 또는 사양서 PDF 파일을 선택하세요.",
        )

        if uploaded_file:
            logger.info(f"파일 업로드됨: {uploaded_file.name}")
            logger.info(f"파일 크기: {uploaded_file.size / 1024:.2f}KB")

    # 메인 컨텐츠
    if category == "파일첨부":
        logger.info("파일첨부 화면 렌더링")
        st.header("📄 계약서 분석")

        if not uploaded_file:
            logger.info("파일 미업로드 상태")
            st.info("👈 사이드바에서 PDF 파일을 업로드해주세요.")
            return

        # 분석 시작
        if st.button("분석 시작", type="primary"):
            logger.info(f"분석 시작 버튼 클릭: {uploaded_file.name}")

            with st.spinner("계약서를 분석중입니다..."):
                # 진행바 표시
                progress_bar = st.progress(0)
                for i in range(100):
                    time.sleep(0.01)
                    progress_bar.progress(i + 1)

                # API 호출 및 결과 분석
                logger.info("계약서 분석 API 호출")
                results = analyze_contract(uploaded_file)

                if results and "violations" in results:
                    logger.info("분석 완료")
                    logger.info(f"위반 건수: {results.get('violation_count', 0)}")

                    st.success("분석이 완료되었습니다!")

                    # 결과 표시
                    col1, col2 = st.columns([2, 1])

                    with col1:
                        st.subheader("📊 분석 결과")
                        violation_count = results.get("violation_count", 0)
                        st.metric("위반 조항 수", violation_count)
                        logger.info(f"표시된 위반 조항 수: {violation_count}")

                        # 위반 사항 목록
                        for idx, violation in enumerate(
                            results["violations"].values(), 1
                        ):
                            with st.expander(f"위반사항 #{idx}"):
                                logger.debug(f"위반사항 #{idx} 표시")
                                st.markdown(
                                    f"""
                                **원문:** {violation.get('content', '')}
                                
                                **위반 유형:** {violation.get('analysis', {}).get('violation_type', '')}
                                
                                **권장 수정안:** {violation.get('analysis', {}).get('suggestion', '')}
                                """
                                )

                    with col2:
                        st.subheader("📈 통계")
                        total_sections = results.get("total_sections", 0)
                        violation_ratio = (
                            (results.get("violation_count", 0) / total_sections * 100)
                            if total_sections > 0
                            else 0
                        )
                        st.metric("검토 항목 수", total_sections)
                        st.metric("위반 비율", f"{violation_ratio:.1f}%")
                        logger.info(
                            f"통계 - 총 섹션: {total_sections}, 위반 비율: {violation_ratio:.1f}%"
                        )

    else:  # 작성방법
        logger.info("작성방법 화면 렌더링")
        st.header("✍️ 작성 방법")
        st.markdown(
            """
        ### 계약서 분석 방법
        1. 사이드바에서 PDF 파일을 업로드합니다.
        2. '분석 시작' 버튼을 클릭합니다.
        3. 분석 결과를 확인합니다.
        
        ### 지원하는 파일 형식
        - PDF 파일 (.pdf)
        
        ### 주의사항
        - 파일 크기는 최대 10MB까지 지원됩니다.
        - 텍스트가 포함된 PDF 파일만 분석 가능합니다.
        - 스캔된 이미지 PDF의 경우 분석이 제한될 수 있습니다.
        """
        )
        st.title("메뉴")
        if st.button("📋 이전 결과 조회"):
            # 세션 상태를 사용하여 페이지 전환
            st.session_state.page = "history"
            st.rerun()

        # 현재 페이지 상태 확인
        if "page" not in st.session_state:
            st.session_state.page = "main"

        # 페이지에 따른 화면 표시
        if st.session_state.page == "main":
            st.title("계약서 분석")
            # 기존의 메인 페이지 코드...
            file = st.file_uploader("계약서 파일 선택 (PDF)", type=["pdf"])
            if file:
                # 기존 분석 로직...
                pass

        elif st.session_state.page == "history":
            # 메인 화면으로 돌아가기 버튼
            if st.button("← 메인으로 돌아가기"):
                st.session_state.page = "main"
                st.rerun()

            # 이전 결과 조회 화면 로드
            load_history_view()


def load_history_view():
    """이전 분석 결과 화면을 호출하는 함수"""
    show_history()


if __name__ == "__main__":
    logger.info("애플리케이션 시작")
    main()
