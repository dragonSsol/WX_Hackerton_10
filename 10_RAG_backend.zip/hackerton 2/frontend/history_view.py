import os
import streamlit as st
from datetime import datetime, timedelta
import pandas as pd
from pathlib import Path
import io
import json
import sys
import requests
import logging
import io

# 프로젝트 루트 경로를 Python 경로에 추가
project_root = str(Path(__file__).parents[1])
sys.path.append(project_root)
from config import API_CONFIG

# CacheManager import
from src.cache_manager import CacheManager

# 로깅 설정
logger = logging.getLogger(__name__)


def fetch_all_analysis_keys():
    """모든 분석 결과의 키 목록 조회"""
    try:
        api_url = f"http://{API_CONFIG['HOST']}:{API_CONFIG['PORT']}/get_analysis_history"
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()
        
        if data and data.get("status") == "success":
            results = data.get("results", {})
            # 키-날짜시간 쌍의 리스트 생성
            key_pairs = []
            for key, result in results.items():
                timestamp = datetime.fromisoformat(result.get("timestamp", ""))
                formatted_time = timestamp.strftime("%Y-%m-%d %H:%M:%S")
                key_pairs.append((key, formatted_time))
            
            # 날짜시간 기준으로 정렬 (최신순)
            return sorted(key_pairs, key=lambda x: x[1], reverse=True)
    except Exception as e:
        logger.error(f"분석 키 목록 조회 중 오류: {str(e)}")
        return []


def fetch_analysis_result(key: str):
    """특정 키의 분석 결과 조회"""
    try:
        api_url = f"http://{API_CONFIG['HOST']}:{API_CONFIG['PORT']}/get_analysis_result/{key}"
        response = requests.get(api_url)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        logger.error(f"분석 결과 조회 중 오류: {str(e)}")
        return None


def load_history_view():
    st.title("계약서 분석 이력 조회")

    # �석 결과 키 목록 조회
    analysis_keys = fetch_all_analysis_keys()
    
    if not analysis_keys:
        st.info("저장된 분석 이력이 없습니다.")
        return

    # 분석 결과 선택
    selected_datetime = st.selectbox(
        "조회할 분석 결과 선택",
        options=[pair[1] for pair in analysis_keys],
        format_func=lambda x: f"분석일시: {x}"
    )
    
    # 선택된 날짜시간에 해당하는 키 찾기
    selected_key = next((pair[0] for pair in analysis_keys if pair[1] == selected_datetime), None)
    
    if selected_key:
        # 선택된 분석 결과 조회
        result = fetch_analysis_result(selected_key)
        
        if result:
            # 메타데이터 표시
            st.subheader("📊 분석 개요")
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("분석 파일", result.get("file_name", "Unknown"))
            with col2:
                st.metric("전체 섹션 수", result.get("total_sections", 0))
            with col3:
                st.metric("위반 건수", result.get("violation_count", 0))

            # 위반 사항 목록
            st.subheader("📝 위반 사항 목록")
            violations = result.get("violations", {})
            
            if violations:
                for section_num, violation in violations.items():
                    with st.expander(f"섹션 {section_num}"):
                        analysis = violation.get("analysis", {})
                        
                        # 원문
                        st.markdown("**원문:**")
                        st.markdown(f"```\n{violation.get('content', '')}\n```")
                        
                        # 위반 내용
                        if analysis.get("detection_flag") == "Y":
                            st.markdown(f"**위반내용:** {analysis.get('comments', '')}")
                            
                            # 개선 문장이 있는 경우
                            if analysis.get("tobe_sentence"):
                                st.markdown("**개선문장:**")
                                st.markdown(f"```\n{analysis.get('tobe_sentence', '')}\n```")
            else:
                st.info("위반 사항이 없습니다.")

            # 내보내기 옵션
            st.subheader("💾 결과 내보내기")
            col1, col2 = st.columns(2)
            with col1:
                if st.button("JSON 다운로드"):
                    json_str = json.dumps(result, ensure_ascii=False, indent=2)
                    st.download_button(
                        label="JSON 파일 다운로드",
                        data=json_str,
                        file_name=f"analysis_result_{selected_key}.json",
                        mime="application/json"
                    )
            with col2:
                if st.button("Excel 다운로드"):
                    # 위반 사항을 DataFrame으로 변환
                    records = []
                    for section_num, violation in violations.items():
                        analysis = violation.get("analysis", {})
                        records.append({
                            "섹션번호": section_num,
                            "페이지": violation.get("page_number", ""),
                            "원문": violation.get("content", ""),
                            "위반내용": analysis.get("comments", ""),
                            "개선문장": analysis.get("tobe_sentence", "")
                        })
                    
                    df = pd.DataFrame(records)
                    excel_buffer = io.BytesIO()
                    df.to_excel(excel_buffer, index=False)
                    
                    st.download_button(
                        label="Excel 파일 다운로드",
                        data=excel_buffer.getvalue(),
                        file_name=f"analysis_result_{selected_key}.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
        else:
            st.error("선택한 분석 결과를 불러올 수 없습니다.")


if __name__ == "__main__":
    load_history_view()
