from flask import Flask, request, jsonify, send_file  # send_file 추가
from flask_cors import CORS
from datetime import datetime
import logging
import os, sys
from pathlib import Path
import re
import json

# 프로젝트 루트 경로를 Python 경로에 추가
project_root = str(Path(__file__).parents[1])
sys.path.append(project_root)

from src import (
    DocumentProcessor,
    Embedder,
    VectorStore,
    KoreanSentenceSplitter,
    RAGChain,
    CacheManager,
)

from config import API_CONFIG, DEFAULT_CONFIG
import tempfile

# 로깅 설정
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.json.ensure_ascii = False
CORS(app)  # 모든 도메인에서의 요청 허용


class ContractAnalyzer:
    _instance = None  # 싱글톤 패턴을 위한 클래스 변수

    @classmethod
    def get_instance(cls, vector_stores_path: str = None):
        """싱글톤 인스턴스 반환"""
        if cls._instance is None:
            # 프로젝트 루트 경로 기준으로 vector_stores 경로 설정
            default_path = os.path.join(project_root, "vector_stores")
            cls._instance = cls(vector_stores_path or default_path)
        return cls._instance

    def __init__(self, vector_stores_path: str):
        """
        계약서 분석기 초기화
        Args:
            vector_stores_path: FAISS 벡터 저장소들이 있는 디렉토리 경로
        """
        self.document_processor = DocumentProcessor()
        self.text_splitter = KoreanSentenceSplitter()
        self.rag_chain = RAGChain()
        self.cache_manager = CacheManager()

        # 벡터 스토어 초기화
        self.vector_stores = {}
        self.load_vector_stores(vector_stores_path)

        logger.info("계약서 분석기 초기화 완료")

    def load_vector_stores(self, vector_stores_path: str, target_store_id: str = None):
        """지정된 벡터스토어가 없으면 가장 최근 벡터 스토어 로드"""
        try:
            logger.info(f"벡터 스토어 로드 시작: {vector_stores_path}")

            if target_store_id:
                logger.info(f"대상 벡터 스토어: {target_store_id}")
                target_path = Path(vector_stores_path) / target_store_id

                if not target_path.exists():
                    logger.error(
                        f"지정된 벡터 스토어를 찾을 수 없음: {target_store_id}"
                    )
                    raise ValueError(
                        f"지정된 벡터 스토어를 찾을 수 없습니다: {target_store_id}"
                    )
                # 메타데이터 로드
                metadata_path = target_path / "metadata.json"
                with open(metadata_path, "r", encoding="utf-8") as f:
                    metadata = json.load(f)

                # FAISS 인덱스 로드
                embedder = Embedder(
                    model_type=metadata["model_type"],
                    model_name=metadata["embedding_model"],
                )
                vector_store = VectorStore(embedder.embeddings)
                vector_store.load_local(str(target_path / "faiss_store"))

                # 벡터 스토어 정보 저장
                timestamp = target_store_id.split("_")[-1]
                self.vector_stores[target_store_id] = {
                    "store": vector_store,
                    "retriever": vector_store.get_retriever(
                        search_kwargs={"k": DEFAULT_CONFIG.get("RETRIEVER_K", 4)}
                    ),
                    "metadata": metadata,
                    "created_at": timestamp,
                }

                logger.info(f"지정된 벡터 스토어 로드 완료: {target_store_id}")

            else:

                # store_ 로 시작하는 모든 디렉토리 찾기
                store_dirs = []
                for d in Path(vector_stores_path).iterdir():
                    if d.is_dir() and d.name.startswith("store_"):
                        try:
                            # store_modeltype_modelname_YYYYMMDD_HHMMSS 형식 파싱
                            timestamp_str = (
                                d.name.split("_")[-2] + "_" + d.name.split("_")[-1]
                            )
                            timestamp = datetime.strptime(
                                timestamp_str, "%Y%m%d_%H%M%S"
                            )
                            store_dirs.append((d, timestamp))
                        except (IndexError, ValueError):
                            logger.warning(
                                f"잘못된 방식의 벡터 스토어 디렉토리: {d.name}"
                            )
                            continue

                if not store_dirs:
                    raise ValueError(
                        f"사용 가능한 벡터 스토어가 없습니다: {vector_stores_path}"
                    )

                # 타임스탬프 기준으로 정렬하고 가장 최근 것만 선택
                latest_store_dir, latest_timestamp = max(store_dirs, key=lambda x: x[1])

                # 메타데이터 로드
                metadata_path = latest_store_dir / "metadata.json"
                if not metadata_path.exists():
                    raise ValueError(f"메타데이터 파일이 없습니다: {metadata_path}")

                with open(metadata_path, "r", encoding="utf-8") as f:
                    metadata = json.load(f)

                # 임베더 및 벡터 스토어 초기화
                embedder = Embedder(
                    model_type=metadata["model_type"],
                    model_name=metadata["embedding_model"],
                )
                vector_store = VectorStore(embedder.embeddings)

                # 벡터 스토어 로드
                store_path = latest_store_dir / "faiss_store"
                if not store_path.exists():
                    raise ValueError(f"벡터 스토어 파일이 없습니다: {store_path}")

                vector_store.load_local(str(store_path))
                self.vector_stores[latest_store_dir.name] = {
                    "store": vector_store,
                    "metadata": metadata,
                    "retriever": vector_store.get_retriever(
                        search_kwargs={"k": DEFAULT_CONFIG.get("RETRIEVER_K", 4)}
                    ),
                    "created_at": latest_timestamp.isoformat(),
                }

                logger.info(
                    f"가장 최근 벡터 스토어 로드 완료: {latest_store_dir.name} (생성일시: {latest_timestamp})"
                )

        except Exception as e:
            logger.error(f"벡터 스토어 로드 중 오류: {str(e)}")
            raise

    def analyze_contract(self, pdf_file, vector_store_id: str = None) -> dict:
        """
        계약서 PDF 파일 분석
        Args:
            pdf_file: PDF 파일 객체
            vector_store_id: 사용할 벡터 스토어 ID (없으면 가장 최근 것 사용)
        Returns:
            분석 결과 딕셔너리
        """
        try:
            # 벡터 스토어 재로드 (최신 상태 유지)
            # 벡터 스토어 로드
            self.load_vector_stores(
                os.path.join(project_root, "vector_stores"),
                target_store_id=vector_store_id,
            )
            logger.info(f"벡터 스토어 목록 갱신 완료")

            if not vector_store_id:
                # 생성 시간 기준으로 가장 최근 벡터 스토어 선택
                try:
                    vector_store_id = max(
                        self.vector_stores.keys(),
                        key=lambda k: datetime.fromisoformat(
                            self.vector_stores[k]["created_at"]
                        ),
                    )
                    logger.info(f"가장 최근 벡터 스토어 선택: {vector_store_id}")
                    logger.info(
                        f"생성 시간: {self.vector_stores[vector_store_id]['created_at']}"
                    )
                except ValueError as e:
                    logger.error(f"벡터 스토어 선택 중 오류: {str(e)}")
                    raise ValueError("사용 가능한 벡터 스토어가 없습니다.")
            else:
                if vector_store_id not in self.vector_stores:
                    available_stores = list(self.vector_stores.keys())
                    raise ValueError(
                        f"벡터 스토어를 찾을 수 없습니다: {vector_store_id}\n사용 가능한 벡터 스토어: {available_stores}"
                    )
                selected_store = self.vector_stores[vector_store_id]
                logger.info(f"지정된 벡터 스토어 사용: {vector_store_id}")

            selected_store = self.vector_stores[vector_store_id]
            retriever = selected_store["retriever"]

            logger.info(f"선택된 벡터 스토어 정보:")
            logger.info(f"- ID: {vector_store_id}")
            logger.info(f"- 모델: {selected_store['metadata']['embedding_model']}")
            logger.info(f"- 생성일시: {selected_store['created_at']}")

            # PDF를 임시 파일로 저장
            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp_file:
                pdf_file.save(tmp_file.name)

                # 1. PDF 문서 로드 및 텍스트 추출
                logger.info("PDF 문서 로드 시작")
                docs = self.document_processor.load_pdf(tmp_file.name)

            # 임시 파일 삭제
            os.unlink(tmp_file.name)

            # 2. 문장 분할
            # logger.info("문서 문장 분할 시작")
            # split_docs = self.text_splitter.split_documents(docs)

            logger.info("문서 넘버링으로 분할 시작")
            split_docs = self.text_splitter.split_by_numbering(docs)

            # 문장 내의 불필요한 따옴표 제거
            for doc in split_docs:
                # doc["content"] = doc["content"].replace('"', "").replace("'", "")
                doc.page_content = doc.page_content.replace('"', "").replace("'", "")

            logger.info(f"분할된 문장 수: {len(split_docs)}")

            # 문서 분석 실행
            analysis_results = {}
            analysis_timestamp = datetime.now().isoformat()
            # 순차적인 인덱스 관리를 위한 카운터 추가
            sequence_counter = 1

            for doc in split_docs:
                try:
                    # 문서 분석 실행
                    result = self.rag_chain.analyze_documents(
                        doc.page_content,
                        retriever,
                        # doc.page_content, selected_store["retriever"]
                    )
                    logger.info(f"########분석 결과: {result}")

                    # response 데이터 추출
                    response_data = result.get("response", {})
                    logger.info(f"########응답: {response_data}")

                    # 위반 여부 확인
                    violation_status = response_data.get("detection_flag", "N")
                    logger.info(f"########응답 데이터1: {violation_status}")

                    # 섹션 번호가 없는 경우도 있기때문에 새로운 구분ID 추가 :페이지 번호 + 시퀀스 번호
                    # identifier = (f"P{doc.metadata.get('page_number', 1)}_{sequence_counter}")

                    # 페이지 번호 검증 및 설정
                    page_num = doc.metadata.get("page_number", 1)
                    if page_num is None or page_num <= 0:
                        logger.warning(
                            f"유효하지 않은 페이지 번호: {page_num}, 기본값 1로 설정"
                        )
                        page_num = 1

                    identifier = f"P{page_num}_{sequence_counter}"
                    logger.info(
                        f"생성된 식별자: {identifier} (페이지: {page_num}, 시퀀스: {sequence_counter})"
                    )

                    if violation_status == "Y":
                        try:
                            # 위반여부가 Y인 경우에만 결과 저장
                            section_number = result.get("section_number")

                            if section_number is None:
                                logger.warning("섹션 번호가 없는 위반사항 발견")
                                section_number = "unknown"

                            result_data = {
                                "identifier": identifier,  # 식별자
                                "section_number": section_number,  # 분석 결과에서 section_number 가져오기
                                "page_number": page_num,
                                "content": doc.page_content,
                                "analysis": response_data,
                                "timestamp": analysis_timestamp,
                            }

                            analysis_results[identifier] = result_data

                        except Exception as e:
                            logger.error(f"결과 저장 중 오류: {str(e)}")
                            logger.error(f"오류 문서 데이터: {doc.metadata}")
                            continue

                except Exception as e:
                    logger.error(f"문서 분석 중 오류:{str(e)}")
                    continue

                sequence_counter += 1
                logger.info(f"섹션 번호 없음 - 대체 식별자 생성: {identifier}")

            # 메타데이터 생성
            metadata = {
                "file_name": pdf_file.filename,
                "processed_at": analysis_timestamp,
                "total_sections": len(split_docs),
                "violation_count": len(analysis_results),
                "vector_store": {
                    "id": vector_store_id,
                    "embedding_model": selected_store["metadata"]["embedding_model"],
                    "model_type": selected_store["metadata"]["model_type"],
                },
            }

            # 전체 분석 결과를 메타데이터와 함께 캐시에 저장
            # 전체 결과 생성
            cache_result = {"metadata": metadata, "violations": analysis_results}

            # 캐시에 결과 저장 (타임스탬프를 키로 사용)
            cache_key = (
                analysis_timestamp.replace(":", "").replace("-", "").replace(".", "")
            )
            self.cache_manager.save_analysis_result(cache_key, cache_result)
            logger.info(f"분석 결과를 캐시에 저장 완료 (캐시 키: {cache_key})")

            return {
                "cache_key": cache_key,
                "metadata": metadata,
                "violations": analysis_results,
            }

        except Exception as e:
            logger.error(f"계약서 분석 중 오류 발생: {str(e)}")
            raise

    def analyze_text(self, text: str, vector_store_id: str = None) -> dict:
        """
        텍스트 직접 분석
        Args:
            text: 분석할 텍스트
            vector_store_id: 사용할 벡터 스토어 ID (없으면 가장 최근 것 사용)
        Returns:
            분석 결과 딕셔너리
        """
        try:
            # 벡터 스토어 재로드 (최신 상태 유지)
            self.load_vector_stores(
                os.path.join(project_root, "vector_stores"),
                target_store_id=vector_store_id,
            )
            logger.info("벡터 스토어 목록 갱신 완료")

            # 벡터 스토어 선택
            if not vector_store_id:
                try:
                    vector_store_id = max(
                        self.vector_stores.keys(),
                        key=lambda k: datetime.fromisoformat(
                            self.vector_stores[k]["created_at"]
                        ),
                    )
                    logger.info(f"가장 최근 벡터 스토어 선택: {vector_store_id}")
                except ValueError as e:
                    logger.error(f"벡터 스토어 선택 중 오류: {str(e)}")
                    raise ValueError("사용 가능한 벡터 스토어가 없습니다.")
            else:
                if vector_store_id not in self.vector_stores:
                    available_stores = list(self.vector_stores.keys())
                    raise ValueError(
                        f"벡터 스토어를 찾을 수 없습니다: {vector_store_id}\n사용 가능한 벡터 스토어: {available_stores}"
                    )
                # selected_store = self.vector_stores[vector_store_id]
                logger.info(f"지정된 벡터 스토어 사용: {vector_store_id}")

            if vector_store_id not in self.vector_stores:
                raise ValueError(f"벡터 스토어를 찾을 수 없습니다: {vector_store_id}")

            selected_store = self.vector_stores[vector_store_id]
            retriever = selected_store["retriever"]

            try:
                # 텍스트 분석 실행
                result = self.rag_chain.analyze_documents(text, retriever)
                logger.info(f"########분석 결과: {result}")

                # response 데이터 추출
                response_data = result.get("response", {})
                logger.info(f"########응답: {response_data}")

                # 위반 여부 확인
                violation_status = response_data.get("detection_flag", "N")
                logger.info(f"########응답 데이터1: {violation_status}")

                # 분석 결과 저장
                analysis_timestamp = datetime.now().isoformat()

                result_data = {
                    "identifier": analysis_timestamp,  # 식별자
                    "text": text,
                    "content": text,
                    "analysis": response_data,
                    "timestamp": analysis_timestamp,
                }
                logger.info(f"########결과 데이터: {result_data}")

            except Exception as e:
                logger.error(f"결과 저장 중 오류: {str(e)}")

            # 메타데이터 생성
            metadata = {
                "type": "text_analysis",
                "processed_at": analysis_timestamp,
                "vector_store": {
                    "id": vector_store_id,
                    "embedding_model": selected_store["metadata"]["embedding_model"],
                    "model_type": selected_store["metadata"]["model_type"],
                },
            }

            # 캐시 키 생성
            cache_key = (
                analysis_timestamp.replace(":", "").replace("-", "").replace(".", "")
            )

            # 전체 결과 생성
            cache_result = {"metadata": metadata, "result": result}

            # 캐시에 결과 저장
            self.cache_manager.save_analysis_result(cache_key, cache_result)
            logger.info(f"분석 결과를 캐시에 저장 완료 (캐시 키: {cache_key})")

            return {"cache_key": cache_key, "metadata": metadata, "result": result}

        except Exception as e:
            logger.error(f"텍스트 분석 중 오류 발생: {str(e)}")
            raise


def get_analyzer():
    """현재 컨텍스트의 분석기 인스턴스 반환"""
    if not hasattr(app, "analyzer"):
        app.analyzer = ContractAnalyzer.get_instance()
    return app.analyzer


# Flask 앱 초기화 시 분석기도 초기화
with app.app_context():
    get_analyzer()


@app.route("/health", methods=["GET"])
def health_check():
    """헬스 체크 엔드포인트"""
    return jsonify({"status": "healthy"})


@app.route("/vector_stores", methods=["GET"])
def list_vector_stores():
    """사용 가능한 벡터 스토어 목록 조회"""
    analyzer = get_analyzer()  # 여기서 분석기 인스턴스를 가져옴
    stores = {
        store_id: {
            "model_type": info["metadata"]["model_type"],
            "embedding_model": info["metadata"]["embedding_model"],
            "document_count": info["metadata"]["document_count"],
            "created_at": info["metadata"]["created_at"],
        }
        for store_id, info in analyzer.vector_stores.items()
    }
    return jsonify(stores)


@app.route("/analyze_contract", methods=["POST"])
def analyze_contract():
    """계약서 분석 엔드포인트"""
    try:
        analyzer = get_analyzer()  # 현재 컨텍스트의 분석기 가져오기

        logger.info("계약서 분석 요청 시작")

        if "file" not in request.files:
            return jsonify({"error": "파일이 없습니다"}), 400

        file = request.files["file"]
        if not file.filename.endswith(".pdf"):
            return jsonify({"error": "PDF 파일만 지원합니다"}), 400

        # 벡터 스토어 ID 가져오기 (선택사항)
        vector_store_id = request.form.get("vector_store_id")
        logger.info(f"벡터 스토어 ID: {vector_store_id}")

        # 계약서 분석 실행
        try:
            results = analyzer.analyze_contract(file, vector_store_id)

            # 응답 생성
            final_response = {
                "status": "success",
                "cache_key": results["cache_key"],
                "metadata": results["metadata"],
                "results": results["violations"],
            }

            # 최종 응답값 출력
            """
            logger.info("=============== 분석 완료 ===============")
            logger.info(f"파일명: {file.filename}")
            logger.info(f"캐시키: {results['cache_key']}")
            logger.info(f"총 섹션 수: {results['metadata']['total_sections']}")
            logger.info(f"위반 항목 수: {results['metadata']['violation_count']}")
            logger.info("위반 항목 상세:")

            if results["violations"]:
                for key, violation in results["violations"].items():
                    logger.info(f"\n[{key}]")
                    logger.info(f"페이지: {violation.get('page_number', 'N/A')}")
                    logger.info(f"섹션: {violation.get('section_number', 'N/A')}")
                    logger.info(
                        f"내용: {violation.get('content', '')[:100]}..."
                    )  # 앞부분 100자만 출력
                    if "analysis" in violation:
                        logger.info(f"분석결과: {violation['analysis']}")
            else:
                logger.info("위반 항목이 없습니다.")

            logger.info("========================================")
            """
            logger.info(f"최종 응답: {final_response}")

            return jsonify(final_response)

        except Exception as e:
            logger.error(f"분석 처리 중 오류: {str(e)}")
            return jsonify({"error": f"분석 처리 중 오류: {str(e)}"}), 500

    except Exception as e:
        logger.error(f"API 요청 처리 중 오류 발생: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route("/get_analysis_result/<key>", methods=["GET"])
def get_analysis_result(key):
    """특정 키의 분석 결과 조회 API"""
    try:
        logger.info(f"분석 결과 조회 요청 (키: {key})")
        analyzer = get_analyzer()  # 여기서 분석기 인스턴스를 가져옴
        result = analyzer.cache_manager.get_analysis_result(key)

        if result:
            logger.info(f"분석 결과 조회 성공 (키: {key})")
            return jsonify({"status": "success", "result": result})

        logger.warning(f"분석 결과를 찾을 수 없음 (키: {key})")
        return (
            jsonify({"status": "error", "message": "분석 결과를 찾을 수 없습니다"}),
            404,
        )

    except Exception as e:
        logger.error(f"분석 결과 조회 중 오류 발생: {str(e)}")
        return (
            jsonify(
                {
                    "status": "error",
                    "message": "결과 조회 중 오류가 발생했습니다",
                    "detail": str(e),
                }
            ),
            500,
        )


@app.route("/cache/info", methods=["GET"])
def get_cache_info():
    """캐시 정보 조회 엔드포인트"""
    analyzer = get_analyzer()  # 여기서 분석기 인스턴스를 가져옴
    try:
        logger.info("캐시 정보 조회 요청")
        cache_info = analyzer.cache_manager.get_cache_info()
        return jsonify(cache_info)
    except Exception as e:
        logger.error(f"캐시 정보 조회 중 오류 발생: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route("/cache/clear", methods=["POST"])
def clear_cache():
    """캐시 초기화 엔드포인트"""
    analyzer = get_analyzer()  # 여기서 분석기 인스턴스를 가져옴
    try:
        logger.info("캐시 초기화 요청")
        analyzer.cache_manager.clear_cache()
        return jsonify({"message": "캐시가 초기화되었습니다"})
    except Exception as e:
        logger.error(f"캐시 초기화 중 오류 발생: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route("/get_analysis_history", methods=["GET"])
def get_analysis_history():
    """분석 이력 조회 API - 전체 결과 조회 및 파일 다운로드 지원"""
    try:
        logger.info("분석 이력 조회 요청")
        analyzer = get_analyzer()
        format_type = request.args.get("format", "json")  # 응답 형식 지정 (json/file)

        # 전체 캐시된 결과 조회
        all_results = analyzer.cache_manager.get_all_results()

        if all_results:
            # 결과를 시간순으로 정렬 (최신순)
            sorted_results = dict(
                sorted(
                    all_results.items(),
                    key=lambda x: x[1].get("timestamp", ""),
                    reverse=True,
                )
            )

            response_data = {
                "status": "success",
                "total_count": len(sorted_results),
                "results": sorted_results,
            }

            # JSON 파일로 내보내기 요청인 경우
            if format_type == "file":
                try:
                    # 결과를 저장할 디렉토리 생성
                    export_dir = Path("exported_results")
                    export_dir.mkdir(exist_ok=True)

                    # 현재 시간을 파일명에 포함
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"analysis_results_{timestamp}.json"
                    file_path = export_dir / filename

                    # JSON 파일로 저장
                    with open(file_path, "w", encoding="utf-8") as f:
                        json.dump(response_data, f, ensure_ascii=False, indent=2)

                    logger.info(f"결과를 JSON 파일로 저장 완료: {file_path}")

                    # 파일 다운로드 응답
                    return send_file(
                        file_path,
                        mimetype="application/json",
                        as_attachment=True,
                        download_name=filename,
                    )
                except Exception as e:
                    logger.error(f"JSON 파일 생성 중 오류 발생: {str(e)}")
                    return (
                        jsonify(
                            {
                                "status": "error",
                                "message": "결과 파일 생성 중 오류가 발생했습니다",
                                "detail": str(e),
                            }
                        ),
                        500,
                    )

            # 일반 JSON 응답
            logger.info(f"분석 이력 조회 성공 (총 {len(sorted_results)}건)")
            return jsonify(response_data)

        # 결과가 없는 경우
        logger.info("저장된 분석 이력 없음")
        return jsonify({"status": "success", "total_count": 0, "results": {}})

    except Exception as e:
        logger.error(f"분석 이력 조회 중 오류 발생: {str(e)}")
        return (
            jsonify(
                {
                    "status": "error",
                    "message": "결과 조회 중 오류가 발생했습니다",
                    "detail": str(e),
                }
            ),
            500,
        )


@app.route("/analyze_text", methods=["POST"])
def analyze_text():
    """텍스트 직접 분석 엔드포인트"""
    try:
        analyzer = get_analyzer()
        logger.info("텍스트 분석 요청 시작")

        # JSON 데이터 검증
        if not request.is_json:
            return jsonify({"error": "JSON 형식으로 요청해주세요"}), 400

        data = request.get_json()
        if "text" not in data:
            return jsonify({"error": "분석할 텍스트를 입력해주세요"}), 400

        text = data["text"]
        vector_store_id = data.get("vector_store_id")
        logger.info(f"벡터 스토어 ID: {vector_store_id}")

        # 텍스트 분석 실행
        try:
            results = analyzer.analyze_text(text, vector_store_id)

            final_response = {
                "status": "success",
                "cache_key": results["cache_key"],
                "metadata": results["metadata"],
                "result": results["result"],
            }

            logger.info(f"최종 응답: {final_response}")
            return jsonify(final_response)

        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        except Exception as e:
            logger.error(f"분석 처리 중 오류: {str(e)}")
            return jsonify({"error": f"분석 처리 중 오류: {str(e)}"}), 500

    except Exception as e:
        logger.error(f"API 요청 처리 중 오류 발생: {str(e)}")
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    from multiprocessing import freeze_support

    freeze_support()

    app.run(host=API_CONFIG["HOST"], port=API_CONFIG["PORT"], debug=API_CONFIG["DEBUG"])
    # app.run(host="0.0.0.0", port=5003)

"""
API 사용 예시:

# 벡터 스토어 목록 조회
curl http://localhost:5003/vector_stores

# 특정 벡터 스토어로 분석
curl -X POST \
  -F "file=@data/구입사양서_B80270CA_S301_1_20240924.pdf" \
  -F "vector_store_id=store_huggingface_bge-m3_20241207_230911" \
  http://localhost:5003/analyze_contract
  
curl -X POST \
-F "file=@data/구입사양서_B80270CA_S301_1_20240924.pdf" \
-F "vector_store_id=store_huggingface_bge-m3_20241207_230911" \
http://localhost:5003/analyze_contract


curl -X POST \
  -F "file=@data/test_6_7.pdf" \
  -F "vector_store_id=store_openai_text-embedding-3-large_20241208_151414" \
  http://localhost:5003/analyze_contract
 
curl -X POST \
  -F "file=@data/test_6_7.pdf" \     
  -F "vector_store_id=store_huggingface_bge-m3_20241207_230911" \                      
   http://localhost:5003/analyze_contract 

  
 curl -X POST \
  -F "file=@data/구입사양서_B80270CA_S301_1_20240924.pdf" \
  http://localhost:5003/analyze_contract


# 특정 분석 결과 조회 (키 값으로 조회)
curl http://localhost:5003/get_analysis_result/20241208T112324290981

# JSON 응답으로 조회
curl http://localhost:5003/get_analysis_history

# 파일로 다운로드
curl http://localhost:5003/get_analysis_history?format=file -o results.json

# 캐시 정보 조회
curl http://localhost:5003/cache/info

# 캐시 초기화
curl -X POST http://localhost:5003/cache/clear


# 텍스트 직접 분석
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{
    "text": "현장 내 주차공간이 없으므로 카풀 및 대중교통을 적극 이용하며, 현장에 출입하는 모든 차량은\n출입허가를득한후출입할수있다.(업체필수차량만승인하며,현장주변은상시주차단속지역)",
    "vector_store_id": "store_openai_text-embedding-3-large_20241208_151414"
  }' \
  http://localhost:5003/analyze_text
    """
