

let currentPage = 1; // 현재 페이지 번호
let totalPages = 0; // 총 페이지 수
const scale = 1.5;
const btnLoad = document.getElementById('btnLoad');
const prevPageButton = document.getElementById('prev-page');
const nextPageButton = document.getElementById('next-page');
const pageInput = document.getElementById('page-input');
const pdfContainer = document.getElementById('pdf-content');
const resultList = document.getElementById('result-list');

const btnTestCreate = document.getElementById('btnTestCreate');
const btnTestDelete = document.getElementById('btnTestDelete');

let listData = [];

document.addEventListener("DOMContentLoaded", function () {    

    // // 결과 항목 예시 추가 및 클릭 이벤트 처리
    // let resultItem = document.createElement('li');
    // resultItem.textContent = '예시 결과 항목';    
    // resultItem.addEventListener('click', function () {
    //     alert('결과 항목이 클릭되었습니다.');
    // });
    // document.getElementById('result-list').appendChild(resultItem);
});

btnLoad.addEventListener('click', ()=>{
    document.getElementById('file-input').click();
    });

    // 파일 입력 요소의 변경 이벤트 처리
    document.getElementById('file-input').addEventListener('change', function (event) {
        const file = event.target.files[0];
        const fileNameElement = document.getElementById('file-name');
        if (file) {
            fileNameElement.textContent = file.name;
            const reader = new FileReader();
            reader.onload = function (e) {
                const pdfData = new Uint8Array(e.target.result);
                //renderPDF(pdfData);

                //불러오기 전 내용 삭제
                const canvases = pdfContainer.querySelectorAll('canvas'); // 모든 <canvas> 요소 선택
                canvases.forEach(canvas => canvas.remove());

                loadPDF(pdfData);
            };
            reader.readAsArrayBuffer(file); // PDF 파일을 ArrayBuffer로 읽음
        } 
        else 
        {
            fileNameElement.textContent = "선택된 파일 없음";
        }
});

// PDF 렌더링 함수
function renderAllPDF(pdfData) {
        
    const loadingTask = pdfjsLib.getDocument(pdfData);
    
    
    loadingTask.promise.then(function (pdf) {
        console.log("PDF loaded");

        totalPages = pdf.numPages;

        // 순차적으로 페이지 렌더링
        const renderPage = (pageNumber) => {
          if (pageNumber > pdf.numPages) return; // 모든 페이지 처리 완료
      
          pdf.getPage(pageNumber).then(function (page) {                
            const viewport = page.getViewport({ scale: scale });
      
            // 캔버스 생성
            const canvas = document.createElement('canvas');            
            const context = canvas.getContext('2d');
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            canvas.dataset.pageNumber = pageNumber;     //이걸해줘야 스크롤이동시 검색
      
            // 페이지 렌더링 설정
            const renderContext = {
              canvasContext: context,
              viewport: viewport,
            };
      
            // 페이지 렌더링 후 다음 페이지 처리
            page.render(renderContext).promise.then(function () {
              pdfContainer.appendChild(canvas);
              //console.log(`Page ${pageNumber} rendered`);
              renderPage(pageNumber + 1); // 다음 페이지 렌더링 호출
            });
          });
        };
      
        pageInput.value = 1;
        // 첫 페이지 렌더링 시작
        renderPage(1);
      });
    }

// 저장 버튼 클릭 이벤트 처리
document.getElementById('save-button').addEventListener('click', function () {
    alert('저장 버튼이 클릭되었습니다.');
});

function scrollToCanvas(pageNumber) {
  const canvas = pdfContainer.querySelector(`canvas[data-page-number="${pageNumber}"]`);

  if (canvas) {
    // canvas로 스크롤 이동
    canvas.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } else {
    console.warn(`Page ${pageNumber} does not exist.`);
  }
}

pageInput.addEventListener('change', (e) => {
    
    const pageNumber = parseInt(e.target.value, 10);

    if (pageNumber >= 1 && pageNumber <= totalPages) {
      currentPage = pageNumber;
      scrollToCanvas(currentPage);
      //renderPage(currentPage);
    } 
    else 
    {
      alert(`Please enter a page number between 1 and ${totalPages}`);
    }
});

// 버튼 이벤트 핸들러
prevPageButton.addEventListener('click', () => {
    if (currentPage > 1) {
      currentPage--;
      pageInput.value = currentPage;
      scrollToCanvas(currentPage);
    }
  });
  
nextPageButton.addEventListener('click', () => {
    if (currentPage < totalPages) {
        currentPage++;
        pageInput.value = currentPage;
        scrollToCanvas(currentPage);
    }
});

btnTestCreate.addEventListener('click', ()=>{    

    const lstTemp = 
    [
        '※ 원사업자는 발주자로부터 선급금을 지급받은 경우에 선급금을 받은 날(하도급 계약체결 전에 받은 경우에는 계약체결일)부터 15일 이내 선급금의 내용과 비율에 따라 수급사업자에게 지급', 
    '※ 어음대체결제수단을 이용하여 대금을 지급하는 경우에는 지급일부터 대금상환기일까지의 기간에 대한 수수료를 지급일에 지급',
    '2. “설계서”라 함은 공사설계설명서, 설계도면, 현장설명서, 공사기간의 산정근거(「국가를 당사자로하는 계약에 관한 법률 시행령」제6장 및 제8장의 계약 및 현장설명서를 작성하는 공사는 제외한다) 및 공종별 목적물 물량내역서(가설물의 설치에 소요되는 물량 포함하며, 이하 "물량내역서"라 한다)를 말한다'
];

addListItem(lstTemp[0], 0, 1, lstTemp[0]);
addListItem(lstTemp[1], 1, 2, lstTemp[1]);
addListItem(lstTemp[2], 2, 5, lstTemp[2]);

    // for (let i = 0; i < lstTemp.length; i++) {
    //     addListItem(lstTemp[i], i, 0, lstTemp[i] + "_1");
    // }
});

btnTestDelete.addEventListener('click', ()=>{
    ClearItems();
});

function ClearItems()
{
    listData.length = 0;
    resultList.innerHTML ='';    
}




  
function addListItem(text, index, page, origin_text) {
    // <li> 요소 생성
    const listItem = document.createElement('li');
    listItem.textContent = text;

    // 텍스트 길이에 따른 동적 스타일 설정
    const textLength = text.length;
    listItem.style.height = 'auto';
    listItem.dataset.index = index;

    // <li> 요소를 <ul>에 추가
    resultList.appendChild(listItem);

    listData.push({
        index: index,
        text: text,
        page: page,
        origin_text: origin_text,
    });

    listItem.addEventListener('click', (event) => {
        FindText(event);
    });
}

function FindText(event)
{
    const clickedItem = event.target;

const selIDX = clickedItem.dataset.index;
    console.log(clickedItem.dataset.index);

    scrollToCanvas(listData[selIDX].page);
    
}


// PDF 로드 함수
function loadPDF(pdfData) {
    renderAllPDF(pdfData);
  }

